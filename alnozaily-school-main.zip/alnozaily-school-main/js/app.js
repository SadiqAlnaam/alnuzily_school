//loading

let loading = document.getElementById("loading");
window.onload = function () {
  loading.classList.add("open");
};
